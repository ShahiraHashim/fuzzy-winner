# Food Detection > 2024-05-19 9:52am
https://universe.roboflow.com/uitm-ahefu/food-detection-lehqz

Provided by a Roboflow user
License: CC BY 4.0

